import OrderCard from "./OrderCard";
import NewOrderPopup from "./NewOrderPopup";
import { useState, useEffect } from "react";

const BASE_URL = "http://localhost:7005";

export const fetchOrders = async () => {
    const response = await fetch(`${BASE_URL}/orders`);
    if (!response.ok) throw new Error("Failed to fetch orders");
    return response.json();
};

export const createOrder = async (order) => {
    const response = await fetch(`${BASE_URL}/orders`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order),
    });
    if (!response.ok) throw new Error("Failed to create order");
    return response.json();
};

const OrderListWithPopup = () => {
    const [orders, setOrders] = useState([]);
    const [showPopup, setShowPopup] = useState(false);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        let isMounted = true; // Prevent setting state if the component is unmounted
        const loadOrders = async () => {
            setLoading(true);
            try {
                const fetchedOrders = await fetchOrders();
                if (isMounted) {
                    setOrders(fetchedOrders);
                    setError(null);
                }
            } catch (err) {
                if (isMounted) {
                    setError(err.message);
                    console.error(err.message);
                }
            } finally {
                if (isMounted) setLoading(false);
            }
        };
        loadOrders();
        return () => {
            isMounted = false; // Cleanup function to avoid state updates after unmount
        };
    }, []);

    const handleCreateOrder = async (newOrder) => {
        try {
            const createdOrder = await createOrder(newOrder);
            setOrders((prevOrders) => [...prevOrders, createdOrder]);
            setShowPopup(false);
        } catch (err) {
            alert("Failed to create order.");
            console.error(err);
        }
    };

    return (
        <div>
            <button onClick={() => setShowPopup(true)} aria-label="Create new order">
                New Order
            </button>
            {error && <div className="error">Error: {error}</div>}
            {loading ? (
                <div>Loading orders...</div>
            ) : (
                <div className="order-list">
                    {orders.map((order, index) => (
                        <OrderCard
                            key={order.id || index}
                            orderNo={order.id}
                            price={order.total_after_tax}
                            date={order.created_at}
                        />
                    ))}
                </div>
            )}
            {showPopup && (
                <NewOrderPopup
                    onClose={() => setShowPopup(false)}
                    onCreate={handleCreateOrder}
                />
            )}
        </div>
    );
};

export default OrderListWithPopup;
